---
name: Question/Discussion
about: General question about how things work or a discussion
title: ''
labels: 'type: discussion'
assignees: ''

---

<!---
Thank you for taking the time to say hello!

Please see our [OSS process document](https://github.com/honeycombio/home/blob/main/honeycomb-oss-lifecycle-and-practices.md#) to get an idea of how we operate.
--->
