# Code of Conduct

This project has adopted the Honeycomb User Community Code of Conduct to clarify expected behavior in our community.

https://www.honeycomb.io/honeycomb-user-community-code-of-conduct/
